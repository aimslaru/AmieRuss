/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 29, 2018, 10:42 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>


using namespace std;

 

int main ()
{
  const double BASE_PRICE = 3.57, // Base price for a gallon of gas
            TOTAL_TAX = 18.4, // total tax on gallon of gas
            PERCENTAGE_PRICE = .225, // percentage price due to gas tax
            PROFIT_RANGE = .650, // oil company profit range
          
    cout << "The base price for a gallon of gas = $ \n"
         >> "The total tax on a gallon of gas = $ \n"
         << "Percentage price due to gas tax = % \n"
         >> "Oil company profit range = % \n"
    
   

    return 0;
}

