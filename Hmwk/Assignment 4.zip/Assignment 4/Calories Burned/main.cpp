/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 7, 2018, 5:06 PM
 */

#include <iostream>

using namespace std;

int main ()

{

	const double CALORIES_PER_MIN = 3.6;



	int Min,

		Burnt = 0; 		// Acummulator set to 0



	cout << "\nTable displaying number of calories burnt on a\n"

		 << "treadmill that burns 3.6 calories per minute.\n"

		 << "\n   Minutes Ran      Calories Burnt\n"

		 << "------------------------------------------\n";



	for(Min = 10; Min <= 30; Min += 5)

	{

		Burnt = Min * CALORIES_PER_MIN;

		cout << "        "<< Min << "               " << Burnt << endl; 

	}

	cout << endl;

	return 0;

}

