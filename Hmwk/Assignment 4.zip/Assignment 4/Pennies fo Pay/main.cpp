/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 10, 2018, 11:34 AM
 */

#include <cstdlib>

using namespace std;
int main ()

{
int num, sum, days; // Initiate the counter
//....this is declaring num,sum and days of type int. It does not initiate or initialize them

//Get integer
cout << "Enter a positive number ";
cin >> days;

cout << "\nNumber Number Summed\n";
cout << "----------------------------\n";

for (int i = 0; i < days; days--)//change to days++
sum+=i;//add
cout << days << "\t\t" << (sum+=days) << endl;//revise to
cout<<"The sum of integers 0 to "<<days<<" is "<<sum<<endl;

return 0; 
}
