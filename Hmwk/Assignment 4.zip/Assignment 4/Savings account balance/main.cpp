/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 7, 2018, 5:08 PM
 */
#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;
 
int main()
{
	// declare variables
	double annInterestRate = 0;
	double startingBalance = 0;
	int monthsPassed = 0;
	double deposits = 0;
	double withdrawal = 0;	
	double totDeposits = 0;
	double totWithdrawal = 0;
	double totInterest = 0;
	double monthlyInterestRate = 0;
	double totBalance = 0;
	
	// obtain data from user
	cout<<"Enter the annual interest rate on the account (e.g .04): ";
	cin >> annInterestRate;
	
	cout<<"Enter the starting balance: $";
	cin >> startingBalance;
	
	cout<<"How many months have passed since the account was established? ";
	cin >> monthsPassed;
	
	// initialize variables with the required info
	totBalance = startingBalance;
	monthlyInterestRate = annInterestRate/12;	
	
	// use a loop to obtain more data from user
	for(int x=1; x <= monthsPassed; ++x)
	{
		cout<<"Month #"<<x<<endl;
		
		cout<<"Total deposits for this month: $";
		cin >> deposits;
		totDeposits += deposits;
		totBalance += deposits;
		
		cout<<"Total withdrawal for this month: $";
		cin >> withdrawal;
		totWithdrawal += withdrawal;
		totBalance -= withdrawal;
		
		totInterest += (totBalance*monthlyInterestRate);
		totBalance += (totBalance*monthlyInterestRate);
 
		// check for negative values
		// end loop if the values are negative
		if(deposits < 0 || withdrawal < 0 || totBalance < 0)
		{
			cout<< "Please enter positive numbers only!";
			cout<<"The account has been closed..n";
			exit(1);
		}
	}
	
	// display results 
	cout<<fixed<<setprecision(2);
	cout.fill('.');
	cout<<"Ending balance:"<<left<<setw(20)<<right<<setw(20)<<" $ "<<totBalance;
	cout<<"Amount of deposits:"<<left<<setw(20)<<right<<setw(16)<<" $ "<<totDeposits;
	cout<<"Amount of withdrawals:"<<left<<setw(20)<<right<<setw(13)<<" $ "<<totWithdrawal;
	cout<<"Amount of interest earned:"<<left<<setw(20)<<right<<setw(9)<<" $ "<<totInterest<<endl;	
	
	return 0;
}
