/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 7, 2018, 5:06 PM
 */

#include <iostream>

using namespace std;
int main ()

{
    int years_Pro = 6;
double membership_Fee = 2500;

for (int i = 0; i <  years_Pro + 1; i++)
{
    cout << " Year: " << i << " which costs: " << membership_Fee << endl;
    membership_Fee *= 1.04; 
}

    return 0;

}
