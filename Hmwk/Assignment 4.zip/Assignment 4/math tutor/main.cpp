/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 7, 2018, 5:07 PM
 */

#include <iostream>
#include <math.h>
#include <cmath>
#include <iomanip>
#include <ctime>
#include <cstdlib>


using namespace std;

int main ()

{
    
}

