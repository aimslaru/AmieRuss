/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 7, 2018, 5:09 PM
 */

#include <iostream>
using namespace std;
int main ()
{
	int number;
	cout<<"Enter a positive integer no greater than 15: "<<" "<<endl;
	cin>>number;
	if (number < 1)
        number = 1;
    else if (number > 15)
        number = 15;
	for (int i=0; i <number; i++)
	{
		for (int j=0; j <number; j++)
		{
			cout<<'X';
		}
		cout<<endl;
	}

return 0;
}

