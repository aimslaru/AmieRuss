/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 19, 2018, 8:29 PM
 */

#include <iostream>

#include <cmath>

using namespace std;



// Fumction Prototypes

double kineticEnergy(int, int);



int main()

{

	int Mass, 		// Mass in kilograms

		Velo;		// Velocity in meters per second



	// Ask user to enter object's mass (in kilograms)

	// and velocity (in meters per second)

	cout << "\nThis program calculates the amount\n"

	     << "of kinetic energy an object has.\n\n"

	     << "Enter the object’s mass (in kilograms): ";

	cin  >> Mass;

	cout << "Enter the object’s velocity (in meters per second): ";

	cin  >> Velo;

	cout << "This object has is "

		 << kineticEnergy(Mass, Velo) << " joules." << endl;

	return 0;

}

double kineticEnergy(int Mass, int Velo)

{   

	return .5 * Mass * pow(Velo, 2);

}
