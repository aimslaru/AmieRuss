/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 22, 2018, 8:33 PM
 */

#include <iostream>

#include <iomanip>

using namespace std;



// Function Prototypes

double celsius(int);



int main()

{

	cout << "\nTable of Fahrenheit temperatures 0 - 20\n"

		 << "and their Celsius equivalents.\n\n"

		 << "------------------------------\n"

		 << "  Fahrenheit       Celsius\n"

		 << "------------------------------\n";

    

	for (int F = 0; F <= 20; F++)

	{

		cout << "      " << setw(2) << F;

		cout << "          "

			 << setw(3) << celsius(F) << endl;

	}

	cout << endl;

	return 0;

}

double celsius(int F)

{

	

	return (5.0 * (F - 32))/9;

}