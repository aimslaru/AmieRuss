/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 22, 2018, 7:42 AM
 */

#include <iostream>
#include <cmath>
using namespace std;

double futureValue(double value, double rate, int num_month){ return value * pow(1 + rate / 100, num_month); }

int main() {
double P, i;
int t;
cout << "Input your present value, monthly interest rate and number of months under the \nspace:";
cin >> P >> i >> t;
cout << "Your future value: " << futureValue(P, i, t) << endl;
return 0;
}