/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 22, 2018, 7:32 PM
 */
#include <iostream>
#include <cstdlib> //for rand and srand
#include <ctime>   //for time function
using namespace std;

int coinFlip(int flipFunc);		//function prototype

int main()
{
	int tosses, count;	//Variables defined
	count = 0;

	cout << "How many tosses should I make?" << endl;		//ask for user input
	cin >> tosses;

	
	while (count <= tosses)   //run loop while less than tosses inputed
	{
		cout << coinFlip << endl;
		count++;		
	}

return 0;					//end code
}
	int coinFlip(int flipFunc)	//flip function
	{	
		unsigned seed = time(0);  //get system time
		srand (seed);			//Seed the random number generator
	
		int flip = 1 + rand() % 2;	//calculates either 1 or 2
			if (flip == 1)
			{
			cout << "Heads!.\n";  // display heads if 1
			}

			else if (flip == 2)
			{
			cout << "Tails!.\n";  //display tails if 2
			}
		return flip;
	}
        