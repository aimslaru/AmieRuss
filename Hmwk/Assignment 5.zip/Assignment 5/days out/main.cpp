/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 20, 2018, 7:59 PM
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;
int main()
{
    srand((unsigned)time(0));
    string userChoice;
    int user;
    int compchoice = (rand()%2)+1;
    cout << "Welcome to Rock, Paper, Scissors,\n";
    cout <<" Please input either rock, paper, or scissors.\n\n";
    cin>>userChoice;
              
    if (userChoice == "rock")
    {user=0;}
    else if (userChoice=="paper")
    {user=1;}
    else if (userChoice=="scissors")
    {user=2;}

    
    if (user==0)
    {
              if (compchoice==0)
              {cout<<endl<<"Computer chose rock"<<endl;
              cout << "It's a tie!\n\n\n\n";
              }
              else if (compchoice == 1)
               {    cout<<endl<<"Computer chose paper"<<endl;
                   cout << "Paper beats rock! Sorry, you lose!\n\n\n\n";
                   }        
              else if (compchoice == 2)
                {
                   cout<<endl<<"Computer chose scissors" <<endl;
                   cout << "Rock beats scissors! You win!\n\n\n\n";
                   }  
    }
    
    
    if (user == 1)
    {
               if (compchoice=0)
               {cout<<endl<<"Computer chose paper"<<endl;
                    cout << "Paper beats rock! You win!\n\n\n\n";
                    }
               else if (compchoice == 1)
               {
               cout<<endl<<"Computer chose paper"<<endl;
               cout << "It's a tie!\n\n\n\n";
               }
               else if (compchoice == 2)
               {
                    cout<<endl<<"Computer chose scissors"<<endl;
                    cout << "Scissors beat paper! Sorry, you lose!\n\n\n\n";
                    }
}
   
  if (user == 2)
 {  
   
             if (compchoice==0)
                      {cout<<endl<<"Computer chose rock"<<endl;
                   cout << "Rock beats scissors! Sorry, you lose!\n\n\n\n";
                   }
              else if (compchoice == 2)
              {cout<<endl<<"Computer chose scissors"<<endl;
              cout << "It's a tie!\n\n\n\n";
              }
              else if (compchoice == 1)
                   {cout<<endl<<"Computer chose paper"<<endl;
                   cout << "Scissors beat paper! You win!\n\n\n\n";
                   }
}  
    return main();
}