/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 21, 2018, 7:18 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

double calculateRetail(double wholesaleCost, double markupPercent)
{
double retailPrice;
retailPrice = (wholesaleCost * markupPercent) + wholesaleCost;
return retailPrice;

}

int main()
{
double wholesaleCost;
double markupPercent;
double total;

double calculateRetail (double, double);

//Enter Wholesale Price
cout << "Enter wholesale Price: $";
cin >> wholesaleCost;

if( wholesaleCost < 0 )
{
cout << "Error invalid wholesale cost...Enter a postive number: $";
cin >> wholesaleCost;
}

//Enter Markup Percentage
cout << "Please Enter markup percent: ";
cin >> markupPercent;

if(markupPercent < 0)
{
cout << "Error invalid markup percentage...enter a postive number ";
cin >> markupPercent;
}

markupPercent = markupPercent * .01;

//This is the function call
total = calculateRetail(wholesaleCost, markupPercent);

cout << fixed << setprecision(2);
cout << "The retail price is $" << total << endl;
cout << endl;

system ("pause");
return 0;
} 