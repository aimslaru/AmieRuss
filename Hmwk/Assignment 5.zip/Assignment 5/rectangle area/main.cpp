/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 21, 2018, 9:23 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

double getsales (double &);
void findhighest (double, double, double, double);

int main(int argc, char *argv[])
{
    double northeast = 0;
    double southeast = 0;
    double northwest = 0;
    double southwest = 0;
    
    cout << "Enter NorthEast sales: $" ;
    cout << getsales(northeast) << endl;
    cout << "Enter SouthEast sales: $"; 
    cout << getsales(southeast) << endl;
    cout << "Enter NorthWest sales: $";
    cout << getsales(northwest) << endl;
    cout << "Enter SouthWest sales: $";
    cout << getsales(southwest) << endl;
    
    findhighest(northeast, southeast, northwest, southwest);
    
  
    return EXIT_SUCCESS;
}

double getsales (double & num)
{
    do
    {
        if(!cin)
        {
            cin.clear();
            cin.ignore(100, '\n');
        }
        
        cin >> num;
        cout << "Number entered: ";
        
        
    }while(!cin || num <= 0);
    return num;
}

void findhighest (double ne, double se, double nw, double sw) 
{
    double high = ne;
    if(se > high)
        high = se;
    if(nw > high)
        high = nw;
    if(sw > high)
        high = sw;
        
    cout << "the highest number is: " << high << endl;
}
