/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:25 PM
 */

#include <iostream>
using namespace std;

int main()
{
double customers = 16500;
 double oneDrink = 0.15;
 double citrus = 0.58;

 cout << "Out of 16500 customers, ";
 cout << customers * oneDrink << " purchase one or more drinks per week \n";
 cout << "Out of 16500, " << (customers * oneDrink) * citrus
  << " prefer citrus flavored energy drinks \n\n"; 
    
 return 0;
}

