/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:18 PM
 */

#include <iostream>
using namespace std;

int main()
{
 double gallons = 15, miles = 375;
 double MPG = miles/gallons;

 cout << "A car that holds " << gallons << " gallons of gasoline and \n"
  << "travels " << miles << " before refueling \n"
  << "gets " << MPG << " MPG \n\n";

 return 0;
}

