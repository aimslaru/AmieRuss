/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:10 PM
 */

#include <iostream>
using namespace std;

int main()
{
 double purchase = 95;
 double statetax = 0.04 * purchase;
 double countytax = 0.02 * purchase;
 double totaltax = statetax + countytax;

 cout << "The total sales tax on a $" << purchase << " purchase is: $"
  << totaltax << endl << endl;

 return 0;
}

