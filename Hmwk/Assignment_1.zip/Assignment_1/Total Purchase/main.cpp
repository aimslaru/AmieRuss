/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:01 PM
 */
#include <iostream>
using namespace std;

int main ()
{
    double itemOne = 15.95, itemTwo = 24.95, itemThree = 6.95, itemFour = 12.95, itemFive = 3.95;
    double subtotal = itemOne + itemTwo + itemThree + itemFour + itemFive;
    double tax = 0.07 * subtotal;
    double total = tax + subtotal; 
    
    cout << "Price of item 1 = $" << itemOne << endl;
    cout << "Price of item 2 = $" << itemTwo << endl;
    cout << "Price of item 3 = $" << itemThree << endl;
 cout << "Price of item 4 = $" << itemFour << endl;
 cout << "Price of item 5 = $" << itemFive << endl << endl;
 cout << "Subtotal = $" << subtotal << endl;
 cout << "Tax = $" << tax << endl;
 cout << "Total = $" << total << endl << endl;
 
 return 0;

}

