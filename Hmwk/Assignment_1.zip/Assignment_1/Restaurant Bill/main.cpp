/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:13 PM
 */

#include <iostream>
using namespace std;

int main()
{
 double meal = 88.67;
 double tax = 0.0675 * meal; //6.75% tax on the meal
 double tip = (tax + meal) * 0.20;  //tip is 20% after adding the tax
 double total = meal + tax + tip;  //total bill

 cout << "The meal charge is: $" << meal << endl;
 cout << "The tax amount is: $" << tax << endl;
 cout << "The tip amount is: $" << tip << endl;
 cout << "The total bill is: $" << total << endl << endl;

 return 0;
}

