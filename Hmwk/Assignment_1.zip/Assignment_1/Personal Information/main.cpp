/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 8:48 PM
 */

#include <iostream>
using namespace std;

int main ()
{
    cout <<"Amie Russ \n"
    <<"12345 Address, Riverside, CA, 92507 \n"
    <<"951-999-9999 \n"
    <<"Cyber Security \n\n";
            
  
    return 0;
    
}


