/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:21 PM
 */

#include <iostream>
using namespace std;

int main()
{
 double acre = 43560;  //1 acre = 43560 sq ft
 double land = 391876; // 391876 sq ft

 double conversion = land / acre;

 cout << land << " sq ft = " << conversion << " acres \n\n";

 return 0;
}
