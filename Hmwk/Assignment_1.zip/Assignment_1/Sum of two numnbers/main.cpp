/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 8:36 PM
 */

#include <iostream>

using namespace std;

int main ()
{
    int numberOne, numberTwo;
    int Total;
    
    numberOne = 50;
    numberTwo = 100;
    
    //To display the total to the screen
    cout<<"The sum of" << numberOne <<"+"<< numberTwo << "= \n";
    
    //calculate total
    Total = numberOne + numberTwo;
    
    cout << Total;
       
    return 0;
}
