/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 24, 2018, 9:15 PM
 */


#include <iostream>
using namespace std;

int main()
{
 int val_one = 28, val_two = 32, val_three = 37, val_four = 24, val_five = 33;
 int sum = val_one + val_two + val_three + val_four + val_five;  //the sum of the values
 double average = sum/5;  //to get the average

 cout << "The sum of " << val_one << " + " << val_two << " + " << val_three
  << " + " << val_four << " + " << val_five << " = " << sum << endl;
 cout << "The average is: " << average << endl << endl;

 return 0;

}

