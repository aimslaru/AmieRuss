/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 1, 2018, 10:05 PM
 */

#include<iostream>

using namespace std;

int main()
{
 double number1, number2;

 cout << "Enter two numbers: ";
 cin >> number1 >> number2;

 if(number1 > number2)
 cout << "The larger number is: " << number1 << endl << endl;
 else
 cout << "The larger number is: " << number2 << endl << endl;

 return 0;
}


