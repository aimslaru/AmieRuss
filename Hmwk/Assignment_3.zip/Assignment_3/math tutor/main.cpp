/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 5, 2018, 6:09 PM
 */

#include<iostream>
#include<iomanip>
#include<ctime>

using namespace std;

int main()
{
 cout << "\n+++++++++++++++++++++++++++++++++++\n"
  << "           Math Tutor"
  << "\n+++++++++++++++++++++++++++++++++++\n\n";

 int number1, number2, sum, answer;
 unsigned seed = time(0);
 

 number1 = 100 + rand() % 999;
 number2 = 100 + rand() % 999;

 sum = number1 + number2;

 cout << setw(5) << number1 << endl;
 cout << setw(5) << number2 << " + \n";
 cout << setw(5) << "------\n\n";

 cout << "Enter the answer: ";
 cin >> answer;

 if(answer == sum)
 cout << "Congratulations, the answer is correct! \n\n";
 else
 cout << "Incorrect answer!! The correct answer is: " << sum << "\n\n";

 return 0;
}
