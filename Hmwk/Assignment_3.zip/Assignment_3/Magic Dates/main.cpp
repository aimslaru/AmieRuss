/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 5, 2018, 5:39 PM
 */

#include <iostream>

using namespace std;

int main ()

{ 
int month, day, year;

 cout << "Enter a month (in numeric form): ";
 cin >> month;
 cout << "Enter a day (1-31): ";
 cin >> day;
 cout << "Enter a two-digit year: ";
 cin >> year;
 
 cout << "\n++++++++++++++++++++++++++++++++\n"
  << "        Magic Dates"
  << "\n++++++++++++++++++++++++++++++++\n";
 
 if(month * day == year)
 cout << "The date is MAGIC !! :) \n\n";
 else
 cout << "The date is NOT magic :( \n\n";

return 0; 

}



