/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 5, 2018, 6:12 PM
 */

#include<iostream>

using namespace std;

int main()
{
 double mass, weight;

 cout << "Enter an object's mass (in Kilograms): ";
 cin >> mass;

 weight = mass * 9.8;

 if(weight > 1000)
 
 cout << "The mass is: " << weight << " newtons \n\n";
 cout << "The object's mass is TOO heavy :( !!\n\n";
 
 if(weight < 10)
 
 cout << "The mass is: " << weight << " newtons \n\n";
 cout << "The object's mass is too Light !! \n\n";
 
 if(weight >=10 && weight <=1000)
 
 cout << "The mass is: " << weight << " newtons \n\n";
return 0; 

}

