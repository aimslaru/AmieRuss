/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 5, 2018, 5:47 PM
 */

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
 double weight, height, BMI;


 cout << "Enter your weight (in pounds): ";
 cin >> weight; 
 cout << "\nEnter your height (in inches): ";
 cin >> height;

 BMI = (weight * 703) / (height * height);

 if(BMI < 18.5)
 cout << "You are under the ideal weight !!  \n\n";
 if(BMI >= 18.5 && BMI <= 25)
 cout << "You are in optimal shape!! Good Work! \n\n";
 if(BMI > 25)
 cout << "You are over the ideal weight \n\n";
 
 return 0;
 
}
