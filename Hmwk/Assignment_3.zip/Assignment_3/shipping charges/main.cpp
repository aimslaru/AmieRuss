/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 5, 2018, 6:11 PM
 */
#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
 double weight, distance, weightCharge, milesCharge, totalCharge;


 cout << "Enter the weight of the package (in Kilograms): ";
 cin >> weight;

 cout << setprecision(2) << fixed;
 if(weight <= 0 || weight > 20)
 
 cout << "Sorry, we cannot ship your package!! \n"
      << "The weight has to be greater than 0 KG and less than 20 Kg!! \n\n";
 
 else
 
 cout << "Enter the distance to be shipped (miles): ";
 cin >> distance;

 if(distance < 10 || distance > 3000)
 
 cout << "Sorry, we cannot ship your package!! \n"
  << "The distance has to be between 10 - 3,000 miles \n\n";
 

 if(weight <= 2)
 milesCharge = (distance/500) * 1.10;
 if(weight > 2 && weight <= 6)
 milesCharge = (distance/500) * 2.20;
 if(weight > 6 && weight <= 10)
 milesCharge = (distance/500) * 3.70;
 if(weight > 10 && weight <= 20)
 milesCharge = (distance/500) * 4.80;

 return 0;
}
