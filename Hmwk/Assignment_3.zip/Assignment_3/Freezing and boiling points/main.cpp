/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on July 5, 2018, 6:14 PM
 */

#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
 double temperature;

 
 cout << "Enter a temperature in Farenheit: ";
 cin >> temperature;

 cout << "\nSubstances that will freeze: \n";
 if(temperature <= -173)
 cout << "Ethyl Alcohol \n";
 if(temperature <= -38)
 cout << "Mercury \n";
 if(temperature <= -362)
 cout << "Oxygen \n";
 if(temperature <= 32)
 cout << "Water \n";
 cout << "\nSubstances that will boil: \n";
 if(temperature >= 172)
 cout << "Ethyl Alcohol \n";
 if(temperature >= 676)
 cout << "Mercury \n";
 if(temperature >= -306)
 cout << "Oxygen \n";
 if(temperature >= 212)
 cout << "Water \n";

 cout << "\n\n";
 
 return 0;
 
}

