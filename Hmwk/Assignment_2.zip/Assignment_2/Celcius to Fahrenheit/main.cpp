/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 27, 2018, 6:25 PM
 */

#include <iostream>

using namespace std;

int main ()
{
    double Celsius, conversion; 
    
    cout << "Enter Celcius temperature: ";
    cin >> Celsius;
    
    conversion = (1.8 * Celsius) + 32;
    
  cout << Celsius << " Celsius = " << conversion << " Fahrenheit \n\n";

  return 0;
}


