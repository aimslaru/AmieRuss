/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 27, 2018, 6:37 PM
 */

#include <iostream>
#include <iomanip>
#include <ctime>


using namespace std;

int main ()

{
double number1, number2, sum;
 char ch;
 unsigned seed = time(0);

 srand(seed);

 number1 = 100 + rand() % 999;
 number2 = 100 + rand() % 999;

 sum = number1 + number2;

 cout << setw(5) << number1 << endl;
 cout << setw(5) << number2<< " + \n";
 cout << setw(5) << "------" << endl << endl;;

 cout << "Enter a character to see the answer: ";
 ch = cin.get();

 cout << setw(5) << sum << endl << endl;

    
    return 0; 
}
