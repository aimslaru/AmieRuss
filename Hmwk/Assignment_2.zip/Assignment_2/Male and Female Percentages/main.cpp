/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 27, 2018, 4:36 PM
 */

#include <iostream>

using namespace std;

int main ()

{
    double cookies, totalCalories; 
    
    cout << "Enter the number of cookies you ate: ";
    cin >> cookies;
    
    /*
     For reference:
     30 cookies in a bag = 10 servings
     3 cookies = 1 serving = 300 calories 
     1.5 cookies = 1/2 serving = 150 calories
     1 cookie = 1/3 serving = 75 calories
     So, 1 cookie = 75 calories
     */
    totalCalories = cookies * 75; 
    cout << "\n\n**********************\n";
    cout << "You consumed: " << totalCalories << " calories! \n\n";

    return 0;
}

