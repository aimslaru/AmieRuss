/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 27, 2018, 5:19 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

int main ()

{
    const double YEN_PER_DOLLAR = 98.93;
    const double EUROS_PER_DOLLAR = .74;
 
    double dollars, yen, euros;
    
    cout << setprecision(2) << fixed ;
    
    cout << "Enter dollar amount: ";
    cin >> dollars;
    
    yen = dollars * YEN_PER_DOLLAR;
    euros = dollars * EUROS_PER_DOLLAR; 
    
 cout << "-------Conversion-------\n";
 cout << "$" << dollars << " = " << yen << " Yen \n";
 cout << "$" << dollars << " = " << euros << " Euros \n\n"; 

 return 0;
}
