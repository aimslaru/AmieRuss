/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 28, 2018, 9:00 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main ()

{
double principal, interestRate, interestAmount, total;
 int timesCompound;

 cout << "\n---------------------------------\n"
  << "       Interest Earned"
  << "\n---------------------------------\n";
 cout << "Enter the principal amount: ";
 cin >> principal;
 cout << "Enter the interest rate: ";
 cin >> interestRate;
 cout << "Enter the number of times the interest is compounded: ";
 cin >> timesCompound;

 interestRate = interestRate/100;

 total = principal * pow((1 + (interestRate/timesCompound)), timesCompound);
 interestAmount = total - principal;

 interestRate = interestRate * 100;
 
  cout << setprecision(2) << fixed;
 cout << "\n----------------------------------\n";
 cout << "Interest Rate:" << "\t\t" << setw(9) << interestRate << "%" << endl;
 cout << "Times Compounded:" << "\t" << setw(9) << timesCompound << endl;
 cout << "Principal:" << "\t\t" << "$" << setw(8) << principal << endl;
 cout << "Interest:" << "\t\t" << "$" << setw(8) << interestAmount << endl;
 cout << "Amount in savings:" << "\t" << "$" << setw(8) << total << endl << endl;
 
     return 0;
}

