/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 27, 2018, 3:47 PM
 */

#include<iostream>
using namespace std; 
int main ()
{
    double capacity, miles, average;
    
    cout << "Enter the number of size of the tank (gallons): ";
    cin >> capacity;
    cout << "Enter the number of miles per tank of gas: ";
    cin >> miles; 
    
    average = miles/capacity;
    cout << "The car's MPG is: " << average << endl << endl; 
    
    return 0;
}

