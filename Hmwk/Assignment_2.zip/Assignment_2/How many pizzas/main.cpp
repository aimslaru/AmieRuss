/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 28, 2018, 8:55 PM
 */

#include <iostream>
#include <iomanip>
    
using namespace std;

int main () 

{
 double diameter, radius, slices, area, totalPizzas;
 double const PI = 3.14159;
 int numberOfPeople;

 cout << "How many people will attend the party: ";
 cin >> numberOfPeople;
 cout << "Enter the diameter of the pizza (inches): ";
 cin >> diameter;

 radius = diameter/2;
 area = PI * radius * radius;
 slices = area/14.125;
 totalPizzas = (numberOfPeople * 4) / slices;

 cout << setprecision(1) << fixed;
 cout << "You will need to order: " << totalPizzas << " pizzas\n\n";
   


 return 0;
}




