/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: amier
 *
 * Created on June 27, 2018, 3:57 PM
 */

#include <iostream>
#include <cmath>
using namespace std;

int main()

{
    double test1, test2, test3, test4, test5; 
    double average; 
    // Get the three test scores.
    cout << "Enter the fist test score: " ;
    cin >> test1;
    cout << "Enter the second test score: " ;
    cin >> test2;
    cout << "Enter the third test score: " ;
    cin >> test3;
    cout << "Enter the fourth test score: " ;
    cin >> test4;
    cout << "Enter the fifth test score: " ; 
    cin >> test5;  
      
    // Calculate the average of the scores.
    average = (test1 + test2 + test3 + test4 + test5) / 5.0; 
    
    // Display the average.
    cout << "The average score is: " << average << endl ; 
    return 0;
}

    
